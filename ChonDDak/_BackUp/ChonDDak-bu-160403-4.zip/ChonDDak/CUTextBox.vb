﻿Public NotInheritable Class CUTextBox : Inherits TextBox

End Class
